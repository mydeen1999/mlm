	(function($) {
		"use strict";

    $(window).load(function(){
      setTimeout(function(){

        $('.loader-live').fadeOut();
      },1000);
    })
	
	})(jQuery);