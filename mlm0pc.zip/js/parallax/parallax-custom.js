	(function($) {
		"use strict";

(function ($) {
		$('.parallax').parallaxBackground();
	})(jQuery);

	
	})(jQuery);